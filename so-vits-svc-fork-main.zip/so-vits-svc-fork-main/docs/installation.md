# Installation

The package is published on [PyPI](https://pypi.org/project/so-vits-svc-fork/) and can be installed with `pip` (or any equivalent):

```bash
pip install so-vits-svc-fork
```
